---
headless: true
bookMenuLevels: 1
---

 - [Experimental setup]({{< relref "/docs/exp-setup/" >}})
   - [Algorithms]({{< relref "/docs/exp-setup/algorithms" >}})
   - [Datasets]({{< relref "/docs/exp-setup/datasets" >}})
   - [Metrics]({{< relref "/docs/exp-setup/metrics" >}})
 - [Results]({{< relref "/docs/results/" >}})
  - [Raw output]({{< relref "/docs/raw-output" >}})
  - [Videos and trails]({{< relref "/docs/videos-and-trails" >}})
 - [Replication]({{< relref "/docs/replication" >}})
