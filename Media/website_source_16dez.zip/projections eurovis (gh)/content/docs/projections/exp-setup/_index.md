---
weight: 3
bookFlatSection: true
title: "Experimental setup"
---
