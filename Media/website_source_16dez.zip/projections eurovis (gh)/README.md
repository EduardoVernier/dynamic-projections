```
hugo server --minify --theme book
```

```
hugo  --minify --theme book
```
