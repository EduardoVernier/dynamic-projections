# Runs


{{< expand "1. cartolastd - 696 observations - 19 timesteps - 17 dimensions - 5 classes" "..." >}}

The dataset was scrapped from the Brazilian fantasy soccer platform Cartola and represents the second turn of the 2017 championship. The scrapper source can be found at https://github.com/henriquepgomide/caRtola. To make the dataset smoother, the dimensions were cumulatively averaged.
{{< youtube id="SKcRJRXL5cg" >}}

| csv file                                                                                                                                            |
|:----------------------------------------------------------------------------------------------------------------------------------------------------|
| [cartolastd-AE_10f_10f_2f_50ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-AE_10f_10f_2f_50ep.csv)     |
| [cartolastd-AE_10f_2f_50ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-AE_10f_2f_50ep.csv)             |
| [cartolastd-VAE_10f_10f_2f_100ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-VAE_10f_10f_2f_100ep.csv) |
| [cartolastd-dtsne_100p_0-1l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-dtsne_100p_0-1l.csv)           |
| [cartolastd-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-pca_s1.csv)                             |
| [cartolastd-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-pca_s4.csv)                             |
| [cartolastd-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-tsne_s1_30p.csv)                   |
| [cartolastd-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cartolastd-tsne_s4_30p.csv)                   |
{{< /expand >}}



{{< expand "2. cifar10cnn - 1000 observations - 30 timesteps - 10 dimensions - 10 classes" "..." >}}

I took the example CNN available at the keras website (https://keras.io/examples/cifar10_cnn/) and looked at the output of the last layer after each epoch for 1000 images of the validation set. After 30 epochs the CNN had an accuracy of 0.6950.
{{< youtube id="jaoB6aJVG4s" >}}

| csv file                                                                                                                                            |
|:----------------------------------------------------------------------------------------------------------------------------------------------------|
| [cifar10cnn-AE_10f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cifar10cnn-AE_10f_10f_2f_20ep.csv)     |
| [cifar10cnn-VAE_100f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cifar10cnn-VAE_100f_10f_2f_20ep.csv) |
| [cifar10cnn-dtsne_30p_0-1l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cifar10cnn-dtsne_30p_0-1l.csv)             |
| [cifar10cnn-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cifar10cnn-pca_s1.csv)                             |
| [cifar10cnn-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cifar10cnn-pca_s4.csv)                             |
| [cifar10cnn-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cifar10cnn-tsne_s1_30p.csv)                   |
| [cifar10cnn-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/cifar10cnn-tsne_s4_30p.csv)                   |
{{< /expand >}}


{{< expand "3. esc50 - 320 observations - 108 timesteps - 128 dimensions - 8 classes" "..." >}}

Sound samples of 8 classes (brushing_teeth, chainsaw, crying_baby, engine, laughing, rain, siren, wind) compressed to 128 frequencies and smoothed over time. Collected from https://github.com/karoldvl/ESC-50 by K. J. Piczak.
{{< youtube id="FZEpRadyAN0" >}}

| csv file                                                                                                                                  |
|:------------------------------------------------------------------------------------------------------------------------------------------|
| [esc50-AE_10f_10f_2f_40ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/esc50-AE_10f_10f_2f_40ep.csv)     |
| [esc50-VAE_100f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/esc50-VAE_100f_10f_2f_20ep.csv) |
| [esc50-dtsne_40p_0-05l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/esc50-dtsne_40p_0-05l.csv)           |
| [esc50-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/esc50-pca_s1.csv)                             |
| [esc50-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/esc50-pca_s4.csv)                             |
| [esc50-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/esc50-tsne_s1_30p.csv)                   |
| [esc50-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/esc50-tsne_s4_30p.csv)                   |
{{< /expand >}}



<!-- your comment text
[fashion-AE_784f_500f_500f_2000f_2f_40ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-AE_784f_500f_500f_2000f_2f_40ep.csv)
[fashion-C2AE_32c_32c_32c_1568f_2f_40ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-C2AE_32c_32c_32c_1568f_2f_40ep.csv)
[fashion-C2VAE_32c_64c_128c_2f_ep40.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-C2VAE_32c_64c_128c_2f_ep40.csv)
[fashion-VAE_784f_2048f_1024f_512f_2f_0-25drop_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-VAE_784f_2048f_1024f_512f_2f_0-25drop_20ep.csv)
[fashion-dtsne_100p_0-1l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-dtsne_100p_0-1l.csv)
[fashion-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-pca_s1.csv)
[fashion-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-pca_s4.csv)
[fashion-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-tsne_s1_30p.csv)
[fashion-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/fashion-tsne_s4_30p.csv)
[gaussians-AE_10f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/gaussians-AE_10f_10f_2f_20ep.csv)
[gaussians-VAE_100f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/gaussians-VAE_100f_10f_2f_20ep.csv)
[gaussians-dtsne_70p_0-1l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/gaussians-dtsne_70p_0-1l.csv)
[gaussians-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/gaussians-pca_s1.csv)
[gaussians-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/gaussians-pca_s4.csv)
[gaussians-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/gaussians-tsne_s1_30p.csv)
[gaussians-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/gaussians-tsne_s4_30p.csv)
[nnset-AE_10f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/nnset-AE_10f_10f_2f_20ep.csv)
[nnset-VAE_100f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/nnset-VAE_100f_10f_2f_20ep.csv)
[nnset-dtsne_60p_0-01l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/nnset-dtsne_60p_0-01l.csv)
[nnset-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/nnset-pca_s1.csv)
[nnset-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/nnset-pca_s4.csv)
[nnset-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/nnset-tsne_s1_30p.csv)
[nnset-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/nnset-tsne_s4_30p.csv)
[qtables-AE_10f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/qtables-AE_10f_10f_2f_20ep.csv)
[qtables-VAE_100f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/qtables-VAE_100f_10f_2f_20ep.csv)
[qtables-dtsne_40p_0-05l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/qtables-dtsne_40p_0-05l.csv)
[qtables-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/qtables-pca_s1.csv)
[qtables-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/qtables-pca_s4.csv)
[qtables-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/qtables-tsne_s1_30p.csv)
[qtables-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/qtables-tsne_s4_30p.csv)
[quickdraw-AE_784f_500f_500f_2000f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-AE_784f_500f_500f_2000f_2f_20ep.csv)
[quickdraw-C2AE_32c_32c_32c_1568f_2f_2ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-C2AE_32c_32c_32c_1568f_2f_2ep.csv)
[quickdraw-C2VAE_32c_64c_128c_6272f_2f_10ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-C2VAE_32c_64c_128c_6272f_2f_10ep.csv)
[quickdraw-VAE_784f_2048f_1024f_512f_2f_0](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-VAE_784f_2048f_1024f_512f_2f_0-25drop_10ep.csv)
[quickdraw-dtsne_200p_0-1l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-dtsne_200p_0-1l.csv)
[quickdraw-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-pca_s1.csv)
[quickdraw-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-pca_s4.csv)
[quickdraw-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-tsne_s1_30p.csv)
[quickdraw-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/quickdraw-tsne_s4_30p.csv)
[sorts-AE_10f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/sorts-AE_10f_10f_2f_20ep.csv)
[sorts-VAE_100f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/sorts-VAE_100f_10f_2f_20ep.csv)
[sorts-dtsne_77p_0-01l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/sorts-dtsne_77p_0-01l.csv)
[sorts-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/sorts-pca_s1.csv)
[sorts-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/sorts-pca_s4.csv)
[sorts-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/sorts-tsne_s1_30p.csv)
[sorts-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/sorts-tsne_s4_30p.csv)
[walk-AE_10f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/walk-AE_10f_10f_2f_20ep.csv)
[walk-VAE_100f_10f_2f_20ep.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/walk-VAE_100f_10f_2f_20ep.csv)
[walk-dtsne_100p_0-01l.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/walk-dtsne_100p_0-01l.csv)
[walk-pca_s1.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/walk-pca_s1.csv)
[walk-pca_s4.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/walk-pca_s4.csv)
[walk-tsne_s1_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/walk-tsne_s1_30p.csv)
[walk-tsne_s4_30p.csv](https://github.com/EduardoVernier/dynamic-projections/blob/master/Output/walk-tsne_s4_30p.csv)
-->
